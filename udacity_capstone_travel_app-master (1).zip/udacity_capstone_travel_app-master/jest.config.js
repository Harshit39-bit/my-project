module.exports = {
    verbose: true,
  };

 